Reports rewritten by required tests are retained here. Original tracked historical report bytes were restored to avoid unrelated historical changes. Current v48 evidence is separate.
